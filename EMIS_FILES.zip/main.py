import sys
from PyQt6.QtWidgets import QApplication, QWidget, QTableWidgetItem, QMainWindow, QMessageBox 
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
from PyQt6 import uic
import mysql.connector

class Employee(QWidget):
    def __init__(self):
        super(Employee, self).__init__()
        uic.loadUi("EMIS.ui", self)
        self.setWindowIcon(QIcon("logo.png"))

        self.start_btn.clicked.connect(self.goto_options)
        self.exit.clicked.connect(self.close_app)
    
    def close_app(self):
        sys.exit()
        
    def goto_options(self):
        self.options = Options()
        self.options.show()
        self.close()
        
class Options(QMainWindow):
    def __init__(self):
        super(Options, self).__init__()
        uic.loadUi("options.ui", self)
        self.setWindowIcon(QIcon("logo.png"))
        
        self.add_record.clicked.connect(self.add_page)
        self.search.clicked.connect(self.searchwindow)
        self.edit.clicked.connect(self.editwindow)
        self.delete_employee.clicked.connect(self.deletewindow)
        self.viewall.clicked.connect(self.viewallwindow)
        self.backbtn.clicked.connect(self.back_page)
        
    def add_page(self):
        self.add = AddPage()
        self.add.show()
        self.close()
        
    def searchwindow(self):
        self.searchwin = SearchEmployees()
        self.searchwin.show()
        self.close()
        
    def editwindow(self):
        self.searchwin = Editemployee()
        self.searchwin.show()
        self.close()
        
    def deletewindow(self):
        self.searchwin = Deleteemployee()
        self.searchwin.show()
        self.close()
        
    def viewallwindow(self):
        self.searchwin = ShowAllEmployees()
        self.searchwin.show()
        self.close()
        
    def back_page(self):
        self.back = Employee()
        self.back.show()
        self.close()
            
class AddPage(QWidget):
    def __init__(self):
        super(AddPage, self).__init__()
        uic.loadUi("add_page.ui", self)
        self.setWindowIcon(QIcon("logo.png"))        

        self.cancelbtn.clicked.connect(self.cancel_btn)
        self.addbtn.clicked.connect(self.adding)
        
    def cancel_btn(self):
        self.canceled = Options()
        self.canceled.show()
        self.close()
        
    def adding(self):
        
         #All the inputs of the add employee page
        self.firstname = self.first.text().title()
        self.middlename = self.middle.text().title()
        self.lastname = self.last.text().title()
        self.age_emp = self.age.value()
        self.sex_emp = self.sex.currentText()
        self.addrs = self.address.text().title()
        self.gmail = self.email.text()
        self.depts = self.department.currentText()
        
        self.updated_sex = None
        self.updated_dept = None
        
        if self.sex_emp == "Male":
            self.updated_sex = 1
        else: 
            self.updated_sex = 2
            
        if self.depts == "Finance":
            self.updated_dept = 1
        elif self.depts == "Marketing":
            self.updated_dept = 2
        elif self.depts == "Information Technology":
            self.updated_dept = 3
        elif self.depts == "Accounting":
            self.updated_dept = 4
        else:
            self.updated_dept = 5
            
        if self.firstname == '' or self.middlename == '' or self.lastname == '' or self.addrs == '' or self.gmail == '':
            QMessageBox.about(self, "Error", "Please fill up all the fields")
        else:
            try: 
                self.conn = mysql.connector.connect(
                    host='localhost',
                    user='root',
                    password='0915',
                    port='3306',
                    database='employee_information'
                )
                self.cursor = self.conn.cursor()
                
                query = f'INSERT INTO employee (FirstName, MiddleName, LastName, Age, Sex_id, Address, Email, Department_id) VALUES ("{self.firstname}", "{self.middlename}", "{self.lastname}", {self.age_emp}, {self.updated_sex}, "{self.addrs}", "{self.gmail}", {self.updated_dept});'
                self.cursor.execute(query)
                self.conn.commit()
                
                QMessageBox.about(self, "Success", "Employee added successfully!")
            except mysql.connector.Error as err:
                QMessageBox.critical(self, "Database Error", f"Failed to add employee: {err}")
            else:
                self.cursor.close()
                self.conn.close()
                self.cancel_btn()

class SearchEmployees(QWidget):
    def __init__(self):
        super(SearchEmployees, self).__init__()
        uic.loadUi("search.ui", self)
        self.setWindowIcon(QIcon("logo.png")) 
        
        self.search.clicked.connect(self.searchemployee)
        self.cancelbtn.clicked.connect(self.cancelpage)
                                       
    def cancelpage(self):
        self.canceled = Options()
        self.canceled.show()
        self.close()
        
    def searchemployee(self):
        id = self.employee_id.text()
        
        try: 
            self.conn = mysql.connector.connect(
                host='localhost',
                user='root',
                password='0915',
                port='3306',
                database='employee_information'
            )
            self.cursor = self.conn.cursor()
            
            query = f"""
        SELECT 
            e.FirstName,
            e.MiddleName,
            e.LastName,
            e.Age,
            s.sex AS Sex,
            e.Address,
            e.Email,
            d.departments AS Department
        FROM 
            employee e
        JOIN
            sex s ON e.Sex_id = s.sex_id
        JOIN
            department d ON e.Department_id = d.dept_id
        WHERE
            e.employee_id = {id}"""
            
            self.cursor.execute(query)
            row = self.cursor.fetchone()
            
            if row is not None:
                self.firstname.setText(row[0])
                self.middlename.setText(row[1])
                self.lastname.setText(row[2])
                self.age.setText(str(row[3]))
                self.sex.setText(row[4])
                self.address.setText(row[5])
                self.email.setText(row[6])
                self.departs.setText(row[7])
            else:
                QMessageBox.about(self, "Error", f"Employee ID: {id} is not found!")
        except mysql.connector.Error as err:
            QMessageBox.critical(self, "Database Error", f"Failed to search employee: {err}")
        else:
            self.cursor.close()
            self.conn.close()
            

class Editemployee(QWidget):
    def __init__(self):
        super(Editemployee, self).__init__()
        uic.loadUi("editpage.ui", self)
        self.setWindowIcon(QIcon("logo.png")) 
        
        self.cancel.clicked.connect(self.cancel_btn)
        self.savebtn.clicked.connect(self.editemployee)
        
    def cancel_btn(self):
        self.cancell = Options()
        self.cancell.show()
        self.close()
        
    def editemployee(self):
        #All the inputs of the add employee page
        self.employe = self.employeeid.text()
        self.firstname = self.first.text().title()
        self.middlename = self.middle.text().title()
        self.lastname = self.last.text().title()
        self.age_emp = self.age.value()
        self.sex_emp = self.sex.currentText()
        self.addrs = self.address.text().title()
        self.gmail = self.email.text()
        self.depts = self.department.currentText()
        
        self.updated_sex = None
        self.updated_dept = None
        
        if self.sex_emp == "Male":
            self.updated_sex = 1
        else: 
            self.updated_sex = 2
            
        if self.depts == "Finance":
            self.updated_dept = 1
        elif self.depts == "Marketing":
            self.updated_dept = 2
        elif self.depts == "Information Technology":
            self.updated_dept = 3
        elif self.depts == "Accounting":
            self.updated_dept = 4
        else:
            self.updated_dept = 5
            
        if self.employe == '' or self.firstname == '' or self.middlename == '' or self.lastname == '' or self.addrs == '' or self.gmail == '':
            QMessageBox.about(self, "Error", "Please fill up all the fields")
        else:
            try: 
                self.conn = mysql.connector.connect(
                    host='localhost',
                    user='root',
                    password='0915',
                    port='3306',
                    database='employee_information'
                )
                self.cursor = self.conn.cursor()
                
                self.cursor.execute(f''' update employee set FirstName = '{self.firstname}', 
                    MiddleName = '{self.middlename}', 
                    LastName = '{self.lastname}', 
                    Age ={self.age_emp}, 
                    Sex_id = {self.updated_sex}, 
                    Address = '{self.addrs}', 
                    Email = '{self.gmail}', 
                    Department_id = {self.updated_dept} 
                    Where employee_id = {int(self.employe)};''')
                self.conn.commit()
                
                QMessageBox.about(self, "Success", "Employee edit successfully!")
                
            except mysql.connector.Error as err:
                QMessageBox.critical(self, "Database Error", f"Failed to edit employee: {err}")
                
            else:
                self.cursor.close()
                self.conn.close()
                self.cancel_btn()
                
                
class Deleteemployee(QWidget):
    def __init__(self):
        super(Deleteemployee, self).__init__()
        uic.loadUi("delete.ui", self)
        self.setWindowIcon(QIcon("logo.png")) 
        
        self.cancel.clicked.connect(self.cancel_btn)
        self.deletebtn.clicked.connect(self.deleting)
    def cancel_btn(self):
        self.option = Options()
        self.option.show()
        self.close()
        
    def deleting(self):
        
        eid = self.employeeid.text()
        
        try:
            self.conn = mysql.connector.connect(
                    host='localhost',
                    user='root',
                    password='0915',
                    port='3306',
                    database='employee_information'
                )
            self.cursor = self.conn.cursor()
            
            query = f'''Delete from employee Where employee_id = {eid}'''
            self.cursor.execute(query)

            self.conn.commit()
            
            QMessageBox.about(self, "Success", "Employee deleted successfully!")
            
        except mysql.connector.Error as err:
             QMessageBox.critical(self, "Database Error", f"Failed to edit employee: {err}")
        
        else:
            self.cursor.close()
            self.conn.close()
            self.cancel_btn()

    def cancel_btn(self):
        self.canceled = Options()
        self.canceled.show()
        self.close()


class ShowAllEmployees(QWidget):
    def __init__(self):
        super(ShowAllEmployees, self).__init__()
        uic.loadUi("show_all.ui", self)
        self.setWindowIcon(QIcon("logo.png"))
        
        self.backbtn.clicked.connect(self.backoption)
        self.load_data()
        
    def backoption(self):
        self.op = Options()
        self.op.show()
        self.close()
        
    def load_data(self):
        try:
            self.conn = mysql.connector.connect(
                host='localhost',
                user='root',
                password='0915',
                port='3306',
                database='employee_information'
            )
            self.cursor = self.conn.cursor()
            
            query = """
                SELECT 
                    e.employee_id,
                    e.FirstName,
                    e.MiddleName,
                    e.LastName,
                    e.Age,
                    s.sex AS Sex,
                    e.Address,
                    e.Email,
                    d.departments AS Department
                FROM 
                    employee e
                JOIN
                    sex s ON e.Sex_id = s.sex_id
                JOIN
                    department d ON e.Department_id = d.dept_id"""
            
            self.cursor.execute(query)
            rows = self.cursor.fetchall()

            if rows:
                self.show_data.setRowCount(len(rows))
                self.show_data.setColumnCount(9)
                self.show_data.setHorizontalHeaderLabels(["Employee ID", "First Name", "Middle Name", "Last Name", "Age", "Sex", "Address", "Email", "Department"])
                self.show_data.verticalHeader().setVisible(False)

                for i, row in enumerate(rows):
                    for j, value in enumerate(row):
                        self.show_data.setItem(i, j, QTableWidgetItem(str(value)))

            else:
                QMessageBox.about(self, "No Records", "No employee records found.")
                
        except mysql.connector.Error as err:
            QMessageBox.critical(self, "Database Error", f"Failed to fetch employees: {err}")
        finally:
            if self.conn.is_connected():
                self.cursor.close()
                self.conn.close()
                self.backoption()


if __name__== '__main__':
    app = QApplication(sys.argv)
    widget = Employee()
    widget.show()
    sys.exit(app.exec())